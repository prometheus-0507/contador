import flet as ft

def main(page: ft.Page):
    page.title = "Contador Simples"
    page.vertical_alignment = ft.MainAxisAlignment.CENTER

    contador = ft.Text(value="0", size=40)

    def incrementar(e):
        contador.value = str(int(contador.value) + 1)
        page.update()

    def decrementar(e):
        contador.value = str(int(contador.value) - 1)
        page.update()

    page.add(
        contador,
        ft.Row(
            [
                ft.ElevatedButton("Incrementar", on_click=incrementar),
                ft.ElevatedButton("Decrementar", on_click=decrementar),
            ],
            alignment=ft.MainAxisAlignment.CENTER
        )
    )

ft.app(target=main)
